package exam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YabsiraApplicationTests {

	@Test
	void contextLoads() {
	}

}
